from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import Base, SessionLocal, engine
from app.models.agent import Agent, AgentRiskLevel
from app import models  # noqa: F401


DEFAULT_AGENTS = [
    {
        "code": "main",
        "name": "主助手",
        "description": "通用问题处理与日常辅助 Agent。",
        "category": "general",
        "openclaw_agent_id": "main",
        "risk_level": AgentRiskLevel.medium,
        "support_files": True,
        "support_images": True,
    },
    {
        "code": "mysql_analysis",
        "name": "MySQL 分析 Agent",
        "description": "用于数据库分析与查询辅助的高风险 Agent。",
        "category": "data",
        "openclaw_agent_id": "huizong-ceshi",
        "risk_level": AgentRiskLevel.high,
        "support_files": False,
        "support_images": False,
    },
    {
        "code": "ppt_generation",
        "name": "PPT 生成 Agent",
        "description": "用于演示文稿内容整理与生成的文档 Agent。",
        "category": "document",
        "openclaw_agent_id": "ppt-generation",
        "risk_level": AgentRiskLevel.medium,
        "support_files": True,
        "support_images": True,
    },
    {
        "code": "image_daoban",
        "name": "刀版合成 Agent",
        "description": "用于图片和刀版合成处理的设计 Agent。",
        "category": "design",
        "openclaw_agent_id": "image-daoban",
        "risk_level": AgentRiskLevel.medium,
        "support_files": True,
        "support_images": True,
    },
    {
        "code": "spider_1688",
        "name": "1688 采集 Agent",
        "description": "用于 1688 数据采集的高风险 Agent。",
        "category": "crawler",
        "openclaw_agent_id": "spider",
        "risk_level": AgentRiskLevel.high,
        "support_files": False,
        "support_images": False,
    },
    {
        "code": "xingzheng",
        "name": "行政快递汇总 Agent",
        "description": "用于行政快递数据汇总和办公报表处理的 Agent。",
        "category": "office",
        "openclaw_agent_id": "xingzheng_a",
        "risk_level": AgentRiskLevel.medium,
        "support_files": True,
        "support_images": True,
    },
]


def seed_agents(db: Session) -> list[Agent]:
    agents: list[Agent] = []
    for agent_data in DEFAULT_AGENTS:
        agent = db.scalar(select(Agent).where(Agent.code == agent_data["code"]))
        if agent is None:
            agent = Agent(**agent_data)
            db.add(agent)
        else:
            for field, value in agent_data.items():
                if field != "code":
                    setattr(agent, field, value)
        agents.append(agent)

    db.commit()
    for agent in agents:
        db.refresh(agent)
    return agents


def main() -> None:
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_agents(db)


if __name__ == "__main__":
    main()
    print("Default agents ensured.")
